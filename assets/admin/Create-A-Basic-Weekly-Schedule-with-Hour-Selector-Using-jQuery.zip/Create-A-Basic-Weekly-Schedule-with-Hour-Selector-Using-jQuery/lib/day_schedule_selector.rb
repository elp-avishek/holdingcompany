require "day_schedule_selector/version"

module DayScheduleSelector
  class Engine < Rails::Engine
  end
end
